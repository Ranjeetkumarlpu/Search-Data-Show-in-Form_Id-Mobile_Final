<!DOCTYPE html>
<html lang="en">
<head>
    <title>Disable/enable the form submit button in jQuery</title>
</head>
<body>

    <form action="" method="post">

        <input type="text" id="firstname" placeholder="First Name" /> <br/><br/>
        <input type="text" id="lastname" placeholder="Last Name"/> <br/><br/>
        <button type="submit" id="mySubmitButton">Submit</button>

    </form>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {

            $('#mySubmitButton').prop('disabled', true);

            $('#firstname, #lastname').keyup(function(){

                if ($('#firstname').val() != '' && $('#lastname').val() != '')
                {
                    $('#mySubmitButton').prop('disabled', false);
                }
                else
                {
                    $('#mySubmitButton').prop('disabled', true);
                }

            });

        });
    </script>

</body>
</html>