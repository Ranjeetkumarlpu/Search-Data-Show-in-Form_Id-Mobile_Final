<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$id_number = $_POST['id_number'];
		$mobilenumber = $_POST['mobilenumber'];
		$email = $_POST['email'];
		$address = $_POST['address'];

		if(!empty($id_number) && !empty($mobilenumber) && !is_numeric($id_number))
		{

			//save to database
			$user_id = random_num(20);
			$query = "insert into users (user_id,id_number,mobilenumber,email,address) values ('$user_id','$id_number','$mobilenumber','$email','$address')";

			mysqli_query($con, $query);

			header("Location: login.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>

	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}

	#box{

		background-color: grey;
		margin: auto;
		width: 300px;
		padding: 20px;
	}

	</style>

<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;"></div>
            Enter Id No:
			<input id="text" type="text" name="id_number" Placeholder ="id number ex:ABabc12345"><br><br>
			Mobile No:
			<input id="text" type="text" name="mobilenumber"><br><br>
			Enter E-mail Id
			<input id="text" type="text" name="email"><br><br>
			Address
			<input id="text" type="text" name="address"><br><br>
			

			<input id="button" type="submit" value="Login"><br><br>

			<a href="signup.php">Click to Signup</a><br><br>
		</form>
	</div>
</body>
</html>