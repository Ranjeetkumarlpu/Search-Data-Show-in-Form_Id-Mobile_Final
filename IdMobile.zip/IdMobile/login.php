<?php 

session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$id_number = $_POST['id_number'];
		$mobilenumber = $_POST['mobilenumber'];

		if(!empty($id_number) && !empty($mobilenumber) && !is_numeric($id_number))
		{

			//read from database
			$query = "select * from users where id_number = '$id_number' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['mobilenumber'] === $mobilenumber)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: index.php");
						die;
					}
				}
			}
			
			echo "wrong idnumber or mobilenumber";
		}else
		{
			echo "wrong idnumber or mobilenumber";
		}
	}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<center><h1>Welcome To My ID Mobile</h1></center>
	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}

	#box{

		background-color: grey;
		margin: auto;
		width: 300px;
		padding: 20px;
	}

	</style>

	<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;"></div>
            Enter Id No:
			<input id="text" type="text" name="id_number"><br><br>
			Mobile No:
			<input id="text" type="text" name="mobilenumber"><br><br>
			Enter E-mail Id
			<input id="text" type="text" name="email"><br><br>
			Address
			<input id="text" type="text" name="address"><br><br>
			

			<input id="button" type="submit" value="Login"><br><br>

			<a href="signup.php">Click to Signup</a><br><br>
		</form>
	</div>
</body>
</html>